import json
import pymysql
#rds settings
rds_host  = "rds-instance-endpoint"
name = "lambda"
password = "lambda"
db_name = "weatherview"

def lambda_handler(event, context):

    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    except:
        logger.error("ERROR: Unexpected error: Could not connect to" + rds_host + " instance.")
        sys.exit()

    return {
        'statusCode': 200,
        'body': json.dumps('All databases up!')
    }
